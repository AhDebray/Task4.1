package com.example.task41;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.makeText;

public class MainActivity extends AppCompatActivity {

    SharedPreferences firstStore, secondStore;
    Chronometer chronometer;
    String timer, task, plain, check, user, last;
    TextView textBox;
    EditText editText;

    long totalTime, pauseTime, stopTime;
    long secA, secB, secC, minA, minB, minC, hrA, hrB, hrC;
    boolean counting, paused;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstStore = getSharedPreferences("com.example.Task41", MODE_PRIVATE);
        secondStore = getSharedPreferences("com.example.Task41", MODE_PRIVATE);

        chronometer = findViewById(R.id.chronometer1);
        textBox = findViewById(R.id.textView1);
        editText = findViewById(R.id.editText1);

        checkStorage();
    }

    public void StartButton(View v){
        if (editText.getText().toString().isEmpty())
        {
            makeText(this, "Enter your task", Toast.LENGTH_LONG).show();
        }
        else
        {
            if(!counting){
                chronometer.setBase(SystemClock.elapsedRealtime() - pauseTime);
                chronometer.start();
                totalTime = SystemClock.elapsedRealtime() - pauseTime;

                counting = !counting;
            }
        }
    }

    public void PauseButton(View v){
        if(counting){
            chronometer.stop();
            pauseTime = SystemClock.elapsedRealtime() - chronometer.getBase();

            counting = !counting;
            paused = false;
        }
    }

    public void StopButton(View v){
        if(counting){
            chronometer.stop();
            stopTime = SystemClock.elapsedRealtime() - chronometer.getBase();

            hrA = (stopTime/1000) / 3600;
            minA = (stopTime/1000) / 60;
            secA = (stopTime/1000) % 60;

            timer = String.format("%02d:%02d:%02d", hrA, minA, secA);
            counting = !counting;
        }
        else
        {
            if(!paused)
            {
                hrB = (pauseTime/1000) / 3600;
                minB = (pauseTime/1000) / 60;
                secB = (pauseTime/1000) % 60;

                timer =  String.format("%02d:%02d:%02d", secB, minB, hrB);
                paused = !paused;
            }
        }

        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseTime = 0;
        stopTime = 0;
        counting = false;
        textBox.setText("You spent "+ timer +" on " + editText.getText().toString() + " last time.");

        SharedPreferences.Editor editor = firstStore.edit();
        SharedPreferences.Editor editor1 = secondStore.edit();
        editor.putString(plain, editText.getText().toString());
        editor1.putString(check, timer);
        editor.apply();
        editor1.apply();
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        pauseTime = savedInstanceState.getLong("Time");
        counting = savedInstanceState.getBoolean("Running");
        totalTime = savedInstanceState.getLong("Current");
        task = savedInstanceState.getString("Name");

        if(counting)
        {
            chronometer.setBase(totalTime);
            chronometer.start();
        }

        if (!counting)
        {
            hrC = (pauseTime/1000) / 3600;
            minC = (pauseTime/1000) / 60;
            secC = (pauseTime/1000) % 60;

            if (pauseTime < 360000)
            {
                chronometer.setText(String.format("%02d:%02d", minC, secC));
            }
            else
            {
                chronometer.setText(String.format("%02d:%02d:%02d", hrC, minC, secC));
            }
        }
    }

    public void checkStorage()
    {
        user = firstStore.getString(plain,"");
        last = secondStore.getString(check,"");
        textBox.setText("You spent "+ last +" on " + user + " last time");
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putLong("Time", pauseTime);
        outState.putBoolean("Running", counting);
        outState.putLong("Current", totalTime);
        outState.putString("Name", editText.getText().toString());
    }
}